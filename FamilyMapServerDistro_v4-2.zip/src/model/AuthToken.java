package model;

public class AuthToken 
{
	public String Authorization; //authentication token
    public String userName;
	public String personId;

}
